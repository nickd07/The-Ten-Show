package thetenshow;


public enum Suit {
    HEARTS, DIAMONDS, CLUBS, SPADES; //card types
}


